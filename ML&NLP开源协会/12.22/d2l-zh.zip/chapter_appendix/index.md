# 附录

```eval_rst

.. toctree::
   :maxdepth: 2

   notation
   math
   jupyter
   aws
   buy-gpu
   how-to-contribute
   d2lzh
```




